class Visualizer:
  def __init__(self, _project_name, _csv_filepath):
    self.project_name = _project_name
    self.csv_filepath = _csv_filepath    
    self.__htmlfile_path = None

  def getVisualizerHtmlFilePath(self):
    pass

  def makeVisualizerHtmlFile(self):
    pass
  
