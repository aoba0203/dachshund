from setuptools import setup, find_packages

setup(
  name = 'dachshund',
  version= '0.3',
  packages = find_packages(),
)

# package apply
# python .\setup.py install --user